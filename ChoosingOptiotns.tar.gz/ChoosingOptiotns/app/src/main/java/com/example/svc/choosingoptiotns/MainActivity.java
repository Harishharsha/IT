package com.example.svc.choosingoptiotns;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioButton r1,r2;
    CheckBox c1,c2,c3,c4,c5,c6;
    Button button;
    Spinner sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        r1=findViewById(R.id.r1);
        r2=findViewById(R.id.r2);
        c1=findViewById(R.id.cb1);
        c2=findViewById(R.id.cb2);
        c3=findViewById(R.id.cb3);
        c4=findViewById(R.id.cb4);
        c5=findViewById(R.id.cb5);
        c6=findViewById(R.id.cb6);
        sp=findViewById(R.id.sp);
        button=findViewById(R.id.btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data="";
                if(r1.isChecked()){
                    data=data+"\n"+r1.getText().toString();
                }
                else {
                    data=data+"\n"+r2.getText().toString();
                }
                if(c1.isChecked()){
                    data=data+"\n"+c1.getText().toString();
                }
                if(c2.isChecked()){
                    data=data+"\n"+c2.getText().toString();
                }
                if(c3.isChecked()){
                    data=data+"\n"+c3.getText().toString();
                }
                if(c4.isChecked()){
                    data=data+"\n"+c4.getText().toString();
                }
                if(c5.isChecked()){
                    data=data+"\n"+c5.getText().toString();
                }
                if(c6.isChecked()){
                    data=data+"\n"+c6.getText().toString();
                }

                data=data+"\n"+sp.getSelectedItem().toString();
                Toast.makeText(MainActivity.this, data,Toast.LENGTH_LONG).show();
            }
        });

    }
}
